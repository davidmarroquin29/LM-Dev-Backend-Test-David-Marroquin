package com.devapps.evaluator.entity.infix.pojo.domain;

public class InfixEvaluation {
	String infix;
	String postfix;
	Double value;
	public String getInfix() {
		return infix;
	}
	public void setInfix(String infix) {
		this.infix = infix;
	}
	public String getPostfix() {
		return postfix;
	}
	public void setPostfix(String postfix) {
		this.postfix = postfix;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	
	

}
