package com.devapps.evaluator.entity.infix.pojo.request;

public class InfixRequest {

	String exp;

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}
	
	
}
