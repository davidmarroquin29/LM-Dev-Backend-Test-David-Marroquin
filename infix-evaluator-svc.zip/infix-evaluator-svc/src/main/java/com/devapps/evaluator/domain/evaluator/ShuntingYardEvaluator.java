package com.devapps.evaluator.domain.evaluator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

import org.springframework.core.env.Environment;

import com.devapps.evaluator.entity.infix.pojo.domain.InfixEvaluation;
import com.devapps.evaluator.exception.InvalidException;

public class ShuntingYardEvaluator implements IEvaluator {
	
	List<String> operandosStr;
	List<String> operadoresStr;
	
	List<String> opList = new ArrayList();
	List<String> outList = new ArrayList();

	public InfixEvaluation evaluate(String expresion, Environment env) throws Exception {
		
		char[] expStr = expresion.toCharArray();
		operandosStr = Arrays.asList(env.getProperty("service.configuration.operandos").split(","));
		operadoresStr = Arrays.asList(env.getProperty("service.configuration.operadores").split(","));
		
		
		
		String output = "";
		
		String type;
		
		getStacks(expStr, opList, outList);
		
		for(String str: outList){
			output+=str + " ";
		}
		
		for (int i = opList.size() - 1; i >= 0; i--) { 
		    output+=opList.get(i) + " "; 
		} 
		
		InfixEvaluation ieval = new InfixEvaluation();
		
		ieval.setInfix(expresion);
		ieval.setPostfix(output);
		ieval.setValue(calculate(Arrays.asList(output.split(" "))));
		
		return ieval;
	}


	private void getStacks(char[] expStr, List<String> opStack, List<String> outStack) throws InvalidException {
		String type;
		for (char c:expStr){
			type = getCharType(c);
			if (type.equals("N")){
				outStack.add(String.valueOf(c));
			}else if(type.equals("O")){
				if (opStack.size() > 0){
					String lastOperator = opStack.get(opStack.size()-1);
					if (operadoresStr.indexOf(lastOperator) >= operadoresStr.indexOf(String.valueOf(c))){
						outStack.add(lastOperator);
						opStack.remove(opStack.size()-1);
					}
				}
				opStack.add(String.valueOf(c));
			}else{
				throw new InvalidException();
			}
		}
	}
	
	
	private String getCharType(char car){
		String caracter = String.valueOf(car);
		if (operandosStr.contains(caracter)){
			return "N"; // numero (operando)
		}else if (operadoresStr.contains(caracter)){
			return "O"; // operador
		}
		return "F"; // Failed
	}
	
	private double calculate(List<String> outputList) {
		 
        Double total = 0.0;
 
        Stack<String> stack = new Stack<String>();
 
        for(String s : outputList){
            if(!operadoresStr.contains(s)){
                stack.push(s);
            }else{
                Double a = Double.valueOf(stack.pop());
                Double b = Double.valueOf(stack.pop());
                int index = operadoresStr.indexOf(s);
                switch(index){
                    case 0:
                        stack.push(String.valueOf(a+b));
                        break;
                    case 1:
                        stack.push(String.valueOf(b-a));
                        break;
                    case 2:
                        stack.push(String.valueOf(a*b));
                        break;
                    case 3:
                        stack.push(String.valueOf(b/a));
                        break;
                }
            }
        }
 
        total = Double.valueOf(stack.pop());
 
        return total;
 
    }
	
}
