package com.devapps.evaluator.exception;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.devapps.evaluator.entity.infix.pojo.exception.ErrorResponse;


@ControllerAdvice
public class EvaluatorExceptionHandler {
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value=InvalidException.class)
	@ResponseBody
	public ErrorResponse handleInvalidException(){
		ErrorResponse response = new ErrorResponse();
		response.setMessage("");
		return null;
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(value=GeneralException.class)
	@ResponseBody
	public ErrorResponse handleGeneralException(){

		return null;
	}

}