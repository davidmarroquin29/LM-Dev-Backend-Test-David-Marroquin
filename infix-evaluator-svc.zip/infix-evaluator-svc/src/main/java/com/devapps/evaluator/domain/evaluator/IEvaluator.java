package com.devapps.evaluator.domain.evaluator;

import org.springframework.core.env.Environment;

import com.devapps.evaluator.entity.infix.pojo.domain.InfixEvaluation;

public interface IEvaluator {
	
	public InfixEvaluation evaluate(String expresion, Environment env) throws Exception;

}
