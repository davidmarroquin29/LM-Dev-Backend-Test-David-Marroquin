package com.devapps.evaluator.process;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.devapps.evaluator.domain.evaluator.IEvaluator;
import com.devapps.evaluator.entity.infix.pojo.domain.InfixEvaluation;
import com.devapps.evaluator.entity.infix.pojo.response.InfixEvaluatorResponse;

public class EvaluatorProcess {
	IEvaluator evaluator;
	Environment env;
	
	public EvaluatorProcess(IEvaluator evaluator, Environment env) {
		super();
		this.evaluator = evaluator;
		this.env = env;
	}

	public InfixEvaluatorResponse process(String infixExp) throws Exception{
		
		InfixEvaluatorResponse response = new InfixEvaluatorResponse();
		
		InfixEvaluation evaluation = evaluator.evaluate(infixExp, env);
		
		response.setInfix(evaluation.getInfix());
		response.setPostfix(evaluation.getPostfix());
		response.setResult(evaluation.getValue());
		
		return response;
	}
	
}
