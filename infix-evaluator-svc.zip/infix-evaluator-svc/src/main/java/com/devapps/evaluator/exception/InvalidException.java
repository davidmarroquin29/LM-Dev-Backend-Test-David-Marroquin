package com.devapps.evaluator.exception;

public class InvalidException extends Exception{

}
