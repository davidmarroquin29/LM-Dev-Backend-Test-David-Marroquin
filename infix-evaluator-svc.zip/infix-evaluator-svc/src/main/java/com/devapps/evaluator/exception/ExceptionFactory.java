package com.devapps.evaluator.exception;

public class ExceptionFactory {

	public Exception getInstance(String exceptionType){
		if (exceptionType.equals("INVALID_EXPRESSION")){
			return new InvalidException();
		}
		if (exceptionType.equals("GENERAL_EXCEPTION")){
			return new GeneralException();
		}
		return null;
		
	}
}
