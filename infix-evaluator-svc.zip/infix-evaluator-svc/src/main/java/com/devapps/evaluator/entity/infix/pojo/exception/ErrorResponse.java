package com.devapps.evaluator.entity.infix.pojo.exception;

public class ErrorResponse {
	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	

}
