package com.evaluator.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.devapps.evaluator.domain.evaluator.ShuntingYardEvaluator;
import com.devapps.evaluator.entity.infix.pojo.domain.InfixEvaluation;
import com.evaluator.test.implementations.EnvironmentImp;

public class EvaluatorTest {

	EnvironmentImp envImp = new EnvironmentImp();
	
	@Test
	public void sumaRestaTest() {
		ShuntingYardEvaluator evaluator = new ShuntingYardEvaluator();
		InfixEvaluation evaluation = new InfixEvaluation();
		
		try {
			evaluation = evaluator.evaluate("1+2-3-4+2", envImp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(evaluation.getPostfix().equals("1 2 - 3 - 4 + 2 +"));
	}
	
	@Test
	public void multiplicacionDivisionTest() {
		ShuntingYardEvaluator evaluator = new ShuntingYardEvaluator();
		InfixEvaluation evaluation = new InfixEvaluation();
		
		try {
			evaluation = evaluator.evaluate("1*2*3/4*2", envImp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(evaluation.getPostfix().equals("1 2 * 3 * 4 / 2 *"));
	}
	
	@Test
	public void combinacionOperacionesTest() {
		ShuntingYardEvaluator evaluator = new ShuntingYardEvaluator();
		InfixEvaluation evaluation = new InfixEvaluation();
		
		try {
			evaluation = evaluator.evaluate("1+5/3*4", envImp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(evaluation.getPostfix().equals("1 5 3 / 4 * +"));
	}
	
	@Test
	public void operacionesDecimalesTest() {
		ShuntingYardEvaluator evaluator = new ShuntingYardEvaluator();
		InfixEvaluation evaluation = new InfixEvaluation();
		
		try {
			evaluation = evaluator.evaluate("1+2.5/3*4", envImp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue(evaluation.getPostfix().equals("1 2.5 3 / 4 * +"));
	}
}
