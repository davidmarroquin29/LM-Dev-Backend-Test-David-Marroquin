package com.devapps.evaluator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devapps.evaluator.domain.evaluator.ShuntingYardEvaluator;
import com.devapps.evaluator.entity.infix.pojo.request.InfixRequest;
import com.devapps.evaluator.entity.infix.pojo.response.InfixEvaluatorResponse;
import com.devapps.evaluator.process.EvaluatorProcess;

@RestController
@RequestMapping("/evaluator")
public class EvaluatorController {
	@Autowired
	Environment env;
	
	@PostMapping("/evaluate")
	public InfixEvaluatorResponse evaluateController(@RequestBody InfixRequest request) throws Exception{
		
		EvaluatorProcess process = new EvaluatorProcess(new ShuntingYardEvaluator(), env);
		InfixEvaluatorResponse response = process.process(request.getExp()); 
		
		return response;
	}

}
