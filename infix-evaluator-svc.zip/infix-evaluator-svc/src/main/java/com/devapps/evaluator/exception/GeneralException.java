package com.devapps.evaluator.exception;

public class GeneralException extends Exception{

}
