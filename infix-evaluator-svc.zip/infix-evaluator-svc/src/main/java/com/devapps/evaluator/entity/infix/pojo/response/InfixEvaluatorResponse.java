package com.devapps.evaluator.entity.infix.pojo.response;

public class InfixEvaluatorResponse {
	String infix;
	String postfix;
	Double result;
	public String getInfix() {
		return infix;
	}
	public void setInfix(String infix) {
		this.infix = infix;
	}
	public String getPostfix() {
		return postfix;
	}
	public void setPostfix(String postfix) {
		this.postfix = postfix;
	}
	public Double getResult() {
		return result;
	}
	public void setResult(Double result) {
		this.result = result;
	}
	
	

}
